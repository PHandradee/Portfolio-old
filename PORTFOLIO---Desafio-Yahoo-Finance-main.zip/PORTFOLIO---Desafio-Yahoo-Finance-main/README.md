# PORTFOLIO---Desafio-Yahoo-Finance

Neste Rápido desafio eu faço um código onde consulta no Yahoo Finance através de sua API um TICKER inputado pelo usuário e,
com isso traz algumas informações a respeito do Ticker como Nome da empresa, data de abertura e etc. 
Além disso é possível o usuário salvar as informções de preço e fechamento das ações da empresa direto no seu GOOGLE DRIVE
e por fim é possível o usuário plotar gráficos de preço e volume.

A proposta é que tudo acontecesse em sequência sem interrupções.
