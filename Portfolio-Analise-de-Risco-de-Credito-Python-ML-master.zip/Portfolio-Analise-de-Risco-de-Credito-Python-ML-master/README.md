# Portfolio-ML-com-Python

Neste projeto utilizo uma base de dados de clientes de um banco alemão para analisar se o crédito deve ser aprovado para cada cliente
ou não, de acordo com vários atributos.

Como forma de treinamento e aprendizagem realizo o projeto através de diversos algoritmos diferentes, entre eles:
Naive Bayes, Árvores de Descição, SVM e KNN.

O resultado mínimo esperado é de 75% de acerto.

Este projeto ainda está em andamento onde irei realizar a análise dos dados e gráficos para conclusão destas informações.
