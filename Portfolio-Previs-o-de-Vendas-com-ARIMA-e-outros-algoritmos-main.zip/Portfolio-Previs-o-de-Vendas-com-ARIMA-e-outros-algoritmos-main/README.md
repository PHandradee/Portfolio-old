# [MAIS_ATUAL]Portfolio-Previsao-de-Vendas-com-ARIMA-e-outros-algoritmos


Projeto em andamento, vou utilizar outras técnicas para aprimorar o modelo e responder as perguntas propostas.

Projeto está sendo refatorado
