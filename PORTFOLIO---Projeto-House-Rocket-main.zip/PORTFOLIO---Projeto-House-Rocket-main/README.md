# PROJETO AINDA EM DESENVOLVIMENTO -- PORTFOLIO---Projeto-House-Rocket

Este projeto foi baseado no desafio proposto pelo site https://sejaumdatascientist.com/os-5-projetos-de-data-science-que-fara-o-recrutador-olhar-para-voce/
do Meigarom e ainda está em desenvolvimento.
